#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 5
#define NOME 15

int main()
{
    char aluno[TAM][TAM][NOME];
    int i, j;
    return 0;
}
